const textElement = document.getElementById('text')
const optionButtonsElement = document.getElementById('option-buttons')

let state = {}

function startGame() {
    state = {}
    showTextNode(1)
}

function showTextNode(textNodeIndex) {
    const textNode = textNodes.find(textNode => textNode.id === textNodeIndex)
    textElement.innerText = textNode.text
    document.getElementById("tile-img").src = textNode.image
    while (optionButtonsElement.firstChild) {
        optionButtonsElement.removeChild(optionButtonsElement.firstChild)
    }

    textNode.options.forEach(option => {
        if (showOption(option)) {
            const button = document.createElement('button')
            button.innerText = option.text
            button.classList.add('btn')
            button.addEventListener('click', () => selectOption(option))
            optionButtonsElement.appendChild(button)
        }
    })
}

function showOption(option) {
    return option.requiredState == null || option.requiredState(state)
}

function selectOption(option) {
    const nextTextNodeId = option.nextText
    if (nextTextNodeId <= 0) {
        return startGame()
    }
    state = Object.assign(state, option.setState)
    showTextNode(nextTextNodeId)
}

const textNodes = [{
        id: 1,
        image: 'assets/images/dark_forest.jpeg',
        text: 'You wake up in a forest at night. It is very dark. The full moon above you provides the only light. You do not remember how you got there. Next to you is a sword. It emanates a silvery light.',
        options: [{
                text: 'Take the glowing sword.',
                setState: {
                    stunPistol: true
                },
                nextText: 2
            },
            {
                text: 'Leave the glowing sword behind.',
                nextText: 2
            }
        ]
    },
    {
        id: 2,
        image: 'assets/images/dead_knight.jpeg',
        text: 'You walk for a few meters through thick vegetation, following a small overgrown path. Next to a tree you find the corpse of a knight. Beside the dead body of the knight you see a longsword and a shield.',
        options: [{
            text: 'Exchange the glowing sword for the longsword.',
            requiredState: (currentState) => currentState.stunPistol,
            setState: {
                stunPistol: false,
                rocketLauncher: true
            },
            nextText: 3,
        }, {
            text: 'Exchange the glowing sword for the shield.',
            requiredState: (currentState) => currentState.stunPistol,
            setState: {
                stunPistol: false,
                bodyShield: true,
            },
            nextText: 3
        }, {
            text: 'Ignore the dead knight.',
            nextText: 3
        }, ]
    },
    {
        id: 3,
        image: 'assets/images/trifurcates.jpg',
        text: 'You leave the dead knight behind and continue walking down the narrow path. After a while the path trifurcates. One path curves to the left, one continues towards the direction you were going, one curves right.',
        options: [{
                text: 'Go left.',
                nextText: 4
            },
            {
                text: 'Follow the path straigh ahead.',
                nextText: 5
            },
            {
                text: 'Go right.',
                nextText: 6
            }
        ]
    },
    {
        id: 4,
        image: 'assets/images/path_curving_left.jpeg',
        text: 'You follow the path that curves left and are almost immidiately attacked by a Werwolf. It pounces on you before you have time to react. In one fell swoop, it cuts your carotid artery with his front claw. Your vision narrows and then...darkness.',
        options: [{
            text: 'Restart',
            nextText: -1
        }]
    },
    {
        id: 5,
        image: 'assets/images/quicksand.jpeg',
        text: 'You follow the path straight ahead, but after a few meters it becomes harder to move. You realize that you are sinking in quicksand. You look for a way out. It is too late. The quicksand pit swallows you whole. Darkness returns. ',
        options: [{
            text: 'Restart',
            nextText: -1
        }]
    },
    {
        id: 6,
        image: 'assets/images/berry_shrubs.jpg',
        text: 'You follow the path curving right. After a while you find a small thorny bush with red berries. You are starving. You eat the red berries and instantly feel reinvigorated. These must have been enchanted berries. You decide to go back to the fork in the road.',
        options: [{
                text: 'Follow the path curving left.',
                nextText: 7
            },
            {
                text: 'Follow the path straight ahead.',
                nextText: 5
            }
        ]
    },
    {
        id: 7,
        image: 'assets/images/Werwolf.jpeg',
        text: 'You follow the path curving left. A werwolf pounces on you and swipes for your head with its front left claw.',
        options: [{
                text: 'Try to reason with it',
                nextText: 8
            },
            {
                text: 'Attack it with your longsword.',
                requiredState: (currentState) => currentState.rocketLauncher,
                nextText: 9
            },
            {
                text: 'Raise your shield to deflect the blow.',
                requiredState: (currentState) => currentState.bodyShield,
                nextText: 10
            },
            {
                text: 'Stab it with your glowing sword.',
                requiredState: (currentState) => currentState.stunPistol,
                nextText: 11
            }
        ]
    },
    {
        id: 8,
        image: 'assets/images/path_curving_left.jpeg',
        text: 'The werwolf is not interested in what you have to say, and decapitates you.',
        options: [{
            text: 'Restart',
            nextText: -1
        }]
    },
    {
        id: 9,
        image: 'assets/images/path_curving_left.jpeg',
        text: 'Your longsword only managed to make some shallow cuts. The werwolf recovers quickly and now you really made it angry. It opens up your belly with its claws and your guts spill all over the forest floor.',
        options: [{
            text: 'Restart',
            nextText: -1
        }]
    },
    {
        id: 10,
        image: 'assets/images/path_curving_left.jpeg',
        text: 'The werwolf knocks over your shield with ease, and decapitates you.',
        options: [{
            text: 'Restart',
            nextText: -1
        }]
    },
    {
        id: 11,
        image: 'assets/images/forest_exit.jpg',
        text: 'You quickly stab the werwolf through the heart with the glowing sword. The monster lets out an otherwordly howl and collapses. You managed to kill it. It seems that it was guarding the path that led out of the woods. You can see the edge of the forest in the distance. You take a death breath, your tense muscles relax. You feel lucky to have survived this ordeal.',
        options: [{
            text: 'Congratulations. Play again.',
            nextText: -1
        }]
    }



]

startGame()