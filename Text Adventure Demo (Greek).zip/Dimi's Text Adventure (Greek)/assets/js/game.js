const textElement = document.getElementById('text')
const optionButtonsElement = document.getElementById('option-buttons')

let state = {}

function startGame() {
    state = {}
    showTextNode(1)
}

function showTextNode(textNodeIndex) {
    const textNode = textNodes.find(textNode => textNode.id === textNodeIndex)
    textElement.innerText = textNode.text
    document.getElementById("tile-img").src = textNode.image
    while (optionButtonsElement.firstChild) {
        optionButtonsElement.removeChild(optionButtonsElement.firstChild)
    }

    textNode.options.forEach(option => {
        if (showOption(option)) {
            const button = document.createElement('button')
            button.innerText = option.text
            button.classList.add('btn')
            button.addEventListener('click', () => selectOption(option))
            optionButtonsElement.appendChild(button)
        }
    })
}

function showOption(option) {
    return option.requiredState == null || option.requiredState(state)
}

function selectOption(option) {
    const nextTextNodeId = option.nextText
    if (nextTextNodeId <= 0) {
        return startGame()
    }
    state = Object.assign(state, option.setState)
    showTextNode(nextTextNodeId)
}

const textNodes = [{
        id: 1,
        image: 'assets/images/dark_forest.jpeg',
        text: 'Ξυπνάς σε ενα δάσος. Είναι νύχτα και όλα είναι πολύ σκοτεινά. Μόνο το λιγοστό φως του φεγγαριού φωτίζει το δασος. Δεν θυμάσαι πως ή γιατί βρίσκεσαι εκεί. Δίπλα σου βλέπεις ένα μικρό σπαθί. Μοιάζει να λάμπει με ένα αλλόκοσμο ασημένιο φως. ',
        options: [{
                text: 'Πάρε το μικρό φωτεινό σπαθί.',
                setState: {
                    stunPistol: true
                },
                nextText: 2
            },
            {
                text: 'Αγνόησε το μικρό φωτεινό σπαθί.',
                nextText: 2
            }
        ]
    },
    {
        id: 2,
        image: 'assets/images/dead_knight.jpeg',
        text: 'Περπατάς για λίγο μέσα σε πυκνή βλάστηση ακολουθώντας ένα μικρό μονοπάτι. Ακουμπησμένο με την πλάτη σε ένα δέντρο βρίσκεις το πτώμα ενός ιππότη. Δίπλα στο νεκρό του σώμα βλέπεις μια μεγάλη σπάθα και την ασπίδα του.',
        options: [{
            text: 'Αντάλλαξε το φωτεινό σπαθί για την μεγάλη σπάθα του ιππότη.',
            requiredState: (currentState) => currentState.stunPistol,
            setState: {
                stunPistol: false,
                rocketLauncher: true
            },
            nextText: 3,
        }, {
            text: 'Αντάλλαξε το φωτεινό σπαθί για την ασπίδα.',
            requiredState: (currentState) => currentState.stunPistol,
            setState: {
                stunPistol: false,
                bodyShield: true,
            },
            nextText: 3
        }, {
            text: 'Αγνόησε τον νερκό ιππότη.',
            nextText: 3
        }, ]
    },
    {
        id: 3,
        image: 'assets/images/trifurcates.jpg',
        text: 'Αφήνεις πίσω σου το νερκό ιππότη και συνεχίζεις να βαδίζεις στο στενό μονοπάτι. Μετά απο μια μικρή απόσταση το μονοπάτι χωρίζεται στα τρία. Ένα μονοπάτι οδηγεί αριστερά, ένα μονοπάτι συνεχίζει ευθεία, προς την κετευθυνση που ακολουθούσες κι ενα τρίτο μονοπάτι πάει δεξιά..',
        options: [{
                text: 'Πήγαινε αριστερά.',
                nextText: 4
            },
            {
                text: 'Πήγαινε ευθεία.',
                nextText: 5
            },
            {
                text: 'Πήγαινε δεξιά.',
                nextText: 6
            }
        ]
    },
    {
        id: 4,
        image: 'assets/images/path_curving_left.jpeg',
        text: 'Ακολουθείς το μονοπάτι που πάει αριστερά και σχεδόν αμέσως έρχεσαι πρόσωπο με πρόσωπο με έναν λυκάνθρωπο. Ορμάει κατα πάνω σου πριν προλάβεις να αντιδράσεις. Με ένα αστραπιαίο χτύπημα από τα μπροστινά του νύχια σου κόβει το λαιμό. Το οπτικό σου πεδίο μικραίνει και μετά...σκοτάδι.',
        options: [{
            text: 'Επανεκκίνηση',
            nextText: -1
        }]
    },
    {
        id: 5,
        image: 'assets/images/quicksand.jpeg',
        text: 'Ακολουθείς το μονοπάτι που συνεχίζει ευθεία, μετά από λίγο όμως αισθάνεσαι μια δυσκολία να προχωρήσεις. Συνηδητοποιείς πως άρχισες να βυθίζεσαι σε κινούμενη άμμο. Προσπαθείς να πιαστείς από έναν κορμό μα αποτυγχάνεις. Είναι ήδη πολύ αργά. Ή άμμος σε καταπίνει. Το σκοτάδι επιστρέφει. ',
        options: [{
            text: 'Επανεκκίνηση',
            nextText: -1
        }]
    },
    {
        id: 6,
        image: 'assets/images/berry_shrubs.jpg',
        text: 'Ακολουθείς το μονοπάτι που πάει προς τα δεξιά. Μετά από λίγο βρίσκεις έναν αγκαθωτό θάμνο με κόκκινα βατόμουρα. Η κοιλιά σου γουργουρίζει, πεθαίνεις της πείνας. Τρώς τα κόκκινα βατόμουρα και αισθάνεσαι σχεδόν αμέσως ανανεωμένος. Αυτά δεν ήταν κοινά βατόμουρα, πρέπει να είχαν μαγικές ιδιότητες. Αποφασίζεις να επιστρέψεις στο σημείο που το αρχικό μονοπάτι χωρίζεται στα τρία.',
        options: [{
                text: 'Ακολούθησε το μονοπάτι που στρίβει αριστερά.',
                nextText: 7
            },
            {
                text: 'Ακολούθησε το μονοπάτι που συνεχίζει ευθεία.',
                nextText: 5
            }
        ]
    },
    {
        id: 7,
        image: 'assets/images/Werwolf.jpeg',
        text: 'Παίρνεις το μονοπάτι που πάει αριστερά. Από το πουθενά ένας λυκάνθρωπος ορμάει πάνω σου, σε ρίχνει κάτω και σε ακινητοποιεί βγάζοντας απειλητικά μουγκρητά. Είναι έτοιμος να σου επιτεθεί με τα αριστερά μπροστινά του νύχια',
        options: [{
                text: 'Προσπάθησε να του μιλήσεις.',
                nextText: 8
            },
            {
                text: 'Επιθέσου με την μεγάλη σπάθα.',
                requiredState: (currentState) => currentState.rocketLauncher,
                nextText: 9
            },
            {
                text: 'Σήκωσε την ασπίδα σου να αποκρούσεις το χτύπημα.',
                requiredState: (currentState) => currentState.bodyShield,
                nextText: 10
            },
            {
                text: 'Κάρφωσε τον με το μικρό φωτεινό σπαθί.',
                requiredState: (currentState) => currentState.stunPistol,
                nextText: 11
            }
        ]
    },
    {
        id: 8,
        image: 'assets/images/path_curving_left.jpeg',
        text: 'Ο λυκάνθρωπος δεν ενδιαφέρεται για το τι έχεις να πεις και σε αποκεφαλίζει ακριαία.',
        options: [{
            text: 'Επανεκκίνηση',
            nextText: -1
        }]
    },
    {
        id: 9,
        image: 'assets/images/path_curving_left.jpeg',
        text: 'Η σπάθα σου προκαλεί μόνο μικρά επιφανειακά τράυματα στον λυκάνθρωπο. Ανακτά αμέσως τις δυνάμεις του και τώρα δείχνει ακόμη πιο θυμωμένος. Με τα νύχια του σου κόβει την κοιλιά και τα περιεχόμενα της χύνονται στο έδαφος.',
        options: [{
            text: 'Επανεκκίνηση',
            nextText: -1
        }]
    },
    {
        id: 10,
        image: 'assets/images/path_curving_left.jpeg',
        text: 'Ο λυκάνθρωπος χτυπάει την ασπίδα και την εκτοξέυει μέτρα λακριά. Σου δαγκώνει το λαιμό. Έντονος πόνος για λίγο και μετά...σκοτάδι.',
        options: [{
            text: 'Επανεκκίνηση',
            nextText: -1
        }]
    },
    {
        id: 11,
        image: 'assets/images/forest_exit.jpg',
        text: 'Χωρίς να χάσεις χρόνο καρφώνεις τον λυκάνθρωπο στο στήθος με το μικρό φωτεινό σπαθί. Το τέρας βγάζει μια σπαρακτική κραυγή και σωριάζεται στο έδαφος νεκρό. Κατάφερες να το σκοτώσεις. Φαίνεται πως φυλούσε το μονοπάτι που οδηγούσε έξω απο το δάσος. Παίρνεις μια βαθιά αναπνοή προσπαθώντας να ηρεμήσεις το σώμα σου που ακόμη τρέμει. Νιώθεις τυχερός που κατάφερες να επιβιώσεις μια τέτοια δοκιμασία.',
        options: [{
            text: 'Συγχαρητήρια, τα κατάφερες! Παίξε ξανά.',
            nextText: -1
        }]
    }



]

startGame()